import hashlib
import json
from pathlib import Path

root = Path('/home/eekeen/projects/oak-bags')
files = []
for directory in sorted(root.glob('phase32-*')):
    for path in sorted(directory.rglob('*')):
        if path.is_file() and not path.is_symlink():
            digest = hashlib.sha256()
            with path.open('rb') as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    digest.update(block)
            files.append({'path': str(path), 'bytes': path.stat().st_size,
                          'sha256': digest.hexdigest()})
Path('/mnt/d/Projects/OakGPT/runs/phase32/bag-inventory-final.json').write_text(
    json.dumps({'files': files, 'bytes': sum(f['bytes'] for f in files),
                'note': 'Local bags retained outside Git; hashes describe actual final files.'}, indent=2))
