import json
from pathlib import Path

alive, incomplete = [], []
files = list(Path('/mnt/d/Projects/OakGPT/runs').glob('phase3*/**/STOPPED.json'))
for path in files:
    spec = json.loads(path.read_text(encoding='utf-8-sig'))
    if spec.get('cleanup_complete') is False:
        incomplete.append(str(path))
    for pid, start in spec.get('owned_processes', {}).items():
        try:
            fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
            if fields[19] == str(start) and fields[0] not in ['Z', 'X']:
                alive.append({'pid': pid, 'start': start, 'session': str(path.parent)})
        except (OSError, IndexError):
            pass
print(json.dumps({'sessions_audited': len(files), 'alive_after_stopped': alive,
                  'incomplete_cleanup_records': incomplete}, indent=2))
