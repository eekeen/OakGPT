# Supplementary selection fixed before these trials: smallest seed, all families.
$phase32Timer = [Diagnostics.Stopwatch]::StartNew()
while (-not (Test-Path -LiteralPath 'runs/phase32/protocol-regression-v1/assertions.json')) {
    if ($phase32Timer.Elapsed.TotalSeconds -gt 5400) { throw 'Protocol cohort did not finish' }
    Start-Sleep -Seconds 2
}
$phase32Generation = Get-Content -LiteralPath 'runs/phase32/held-out-worlds-v1/generation.json' -Raw | ConvertFrom-Json
$phase32Seed = ($phase32Generation.start_seeds | Measure-Object -Minimum).Minimum.ToString('0')
foreach ($phase32Family in @('empty', 'block', 'wall')) {
    $phase32World = "runs/phase32/held-out-worlds-v1/$phase32Family-$phase32Seed"
    $phase32Output = "runs/phase32/heldout-stop-$phase32Family-v1"
    & .venv-phase31-verify/Scripts/python.exe scripts/motion_faults.py `
        --world $phase32World --output $phase32Output `
        --install /home/eekeen/projects/oak-ros-phase32-v5 --launch expiry.launch.py `
        --fastdds-profile configs/robotics/phase32_fastdds_services.xml `
        --overlay configs/robotics/phase32_corrected.json `
        --freeze configs/robotics/phase32_freeze.json --cases guard_crash `
        *> "runs/phase32-heldout-stop-$phase32Family-v1.log"
    if ($LASTEXITCODE -ne 0) { throw "Stopping harness failed: $phase32Family" }
}
