python scripts/verify_phase33_archive.py
if ($LASTEXITCODE -ne 0) { throw "Archive verification failed" }
$replay = Join-Path (Get-Location) "runs/phase33/reproduced-evidence-v1"
New-Item -ItemType Directory -Path $replay -ErrorAction Stop | Out-Null
foreach ($variant in @("phase32_sync", "candidate")) {
    $bundle = if ($variant -eq "candidate") { "final-study-candidate-v1" } else { "final-study-baseline-v1" }
    $target = Join-Path $replay "study/$variant"
    New-Item -ItemType Directory -Path $target -ErrorAction Stop | Out-Null
    foreach ($archive in Get-ChildItem "reports/phase33/$bundle/raw/*.tar.gz") {
        tar -xzf $archive.FullName -C $target
        if ($LASTEXITCODE -ne 0) { throw "Extraction failed" }
    }
}
New-Item -ItemType Directory -Path "$replay/faults/cases" -ErrorAction Stop | Out-Null
foreach ($archive in Get-ChildItem "reports/phase33/final-faults-v1/raw/*.tar.gz") {
    tar -xzf $archive.FullName -C "$replay/faults/cases"
    if ($LASTEXITCODE -ne 0) { throw "Extraction failed" }
}
tar -xzf reports/phase33/final-session-index-v1/raw/final-session-index-v1.tar.gz -C $replay
if ($LASTEXITCODE -ne 0) { throw "Index extraction failed" }
$index = Join-Path $replay "final-session-index-v1"
Copy-Item -LiteralPath "$index/held-out-schedule.json" -Destination "$replay/study/schedule.json"
Copy-Item -LiteralPath "$index/held-out-paired-results.json" -Destination "$replay/study/paired_results.json"
Copy-Item -LiteralPath "$index/fault-plan.json" -Destination "$replay/faults/plan.json"
Copy-Item -LiteralPath "$index/fault-COMPLETE" -Destination "$replay/faults/COMPLETE"
if (@(Get-ChildItem "$replay/study/*/*/result.json").Count -ne 48) { throw "Missing sessions" }
New-Item -ItemType File -Path "$replay/study/COMPLETE" -ErrorAction Stop | Out-Null
python scripts/analyze_phase33_final.py --root "$replay/study" --output "$replay/navigation.json"
if ($LASTEXITCODE -ne 0) { throw "Navigation scoring failed" }
python scripts/analyze_phase33_faults.py --root "$replay/faults" --output "$replay/faults.json"
if ($LASTEXITCODE -ne 0) { throw "Fault scoring failed" }
python scripts/build_phase33_final_report.py --navigation "$replay/navigation.json" --faults "$replay/faults.json" --verification reports/phase33/verification-final-v1.json --study "$replay/study" --output "$replay/report"
if ($LASTEXITCODE -ne 0) { throw "Report generation failed" }
