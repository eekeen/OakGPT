﻿import json,os,signal,time
from pathlib import Path
pid=238792; expected='99360140'
proc=Path('/proc')/str(pid)
fields=(proc/'stat').read_text().rsplit(')',1)[1].split()
if fields[19]!=expected or fields[0]=='Z': raise RuntimeError('Owned orphan identity changed')
record={'pid':pid,'start':expected,'before_monotonic_ns':time.monotonic_ns(),'reason':'Phase32 supervisor marked STOPPED but this exact owned Gazebo descendant remained live','signal':'SIGKILL'}
os.kill(pid,signal.SIGKILL)
record['after_monotonic_ns']=time.monotonic_ns()
with Path('/mnt/d/Projects/OakGPT/runs/phase32/cleanup-orphan-remediation.json').open('x') as f:json.dump(record,f,indent=2)
print('Stopped exactly one previously recorded, identity-verified orphan')
