# Only strata lacking valid v1 motion injections; v1 evidence remains unchanged.
$phase32Wait = [Diagnostics.Stopwatch]::StartNew()
while (-not (Test-Path -LiteralPath 'runs/phase32/expiry-supplementary-v2/motion.json')) {
    if ($phase32Wait.Elapsed.TotalSeconds -gt 600) { throw 'Supplementary expiry study incomplete' }
    Start-Sleep -Seconds 2
}
foreach ($phase32Family in @('block', 'wall')) {
    & .venv-phase31-verify/Scripts/python.exe scripts/motion_faults.py `
        --world "runs/phase32/held-out-worlds-v1/$phase32Family-465863172" `
        --output "runs/phase32/heldout-stop-$phase32Family-v2" `
        --install /home/eekeen/projects/oak-ros-phase32-v5 --launch expiry.launch.py `
        --fastdds-profile configs/robotics/phase32_fastdds_services.xml `
        --overlay configs/robotics/phase32_corrected.json `
        --freeze configs/robotics/phase32_freeze_v2.json --cases guard_crash `
        *> "runs/phase32-heldout-stop-$phase32Family-v2.log"
    if ($LASTEXITCODE -ne 0) { throw "Stopping follow-up failed: $phase32Family" }
}
