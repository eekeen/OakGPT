# Preserved development and procedural failures

- A fresh installed v3 ROS test failed collection because Jazzy does not export rclpy.qos.qos_profile_clock. The runtime now declares explicit depth-one BEST_EFFORT QoS. Fresh v4 and final v5 installed tests pass; failed logs are retained.
- The first source-only shell check had a CRLF command-line issue, followed by a PYTHONPATH override that hid ROS packages. These were verification setup errors, not Gazebo trials; corrected source tests pass.
- One initial cross-peer assertion incorrectly expected invalid replacement traffic to revoke a still-fresh legitimate inactive incarnation. The corrected assertion checks no binding/freshness change, no new active authorization, and expiration at the original deadline. Console-only failed attempt was 1 failed / 16 passed; the final installed suite passes.
- An installed-file inventory helper expected a nonexistent liboak_nav_trace.so. It was corrected to enumerate the actual controller, progress and transport libraries plus expiry. All final installed Python and four native library hashes are recorded.
- A WSL Git history scan reported CRLF/LF differences for preexisting Windows files; native Windows Git reported no protected changes. No archive/source bytes were normalized or rewritten. A contemplated owned-scan cleanup found the process had already exited; no signal was delivered. The failed cleanup diagnostic is retained.
- An evidence collector encountered Windows reparse aliases in colcon logs. Resumed export compares existing bytes and uses the existing no-alias traversal; it does not overwrite mismatched files.
- Offline review found a zero-source stamp could bind an otherwise invalid fresh incarnation before rejection at simulated boot zero. Positive source validation now precedes mutation, with a regression test. No observed live authorization involved this edge case.
- The single live-admission gate failed all three samples. No Gazebo trial was dispatched, no acceptance criterion changed, no consumed world was reused, and no unrelated process was terminated. Private process sampling remains outside Git; the game client was the main competing workload.

Intermediate source snapshots/builds v1-v4 remain intact. Only v5 is the final tested development install. This is not an independently frozen or validated candidate.
