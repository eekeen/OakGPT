﻿import json
from pathlib import Path
alive=[]
for path in Path('/mnt/d/Projects/OakGPT/runs/phase32').glob('**/STOPPED.json'):
 spec=json.loads(path.read_text())
 for key,start in spec.get('owned_processes',{}).items():
  proc=Path('/proc')/str(key)
  try:
   fields=(proc/'stat').read_text().rsplit(')',1)[1].split()
   if fields[19]==start and fields[0]!='Z':
    alive.append({'pid':int(key),'start':start,'session':str(path.parent),'command':(proc/'cmdline').read_bytes().decode().replace(chr(0),' ')})
  except (OSError,IndexError):pass
print(json.dumps({'alive_after_stopped':alive},indent=2))
