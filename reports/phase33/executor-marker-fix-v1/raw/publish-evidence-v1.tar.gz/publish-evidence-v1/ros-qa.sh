#!/usr/bin/env bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
prefix=/home/eekeen/projects/oak-phase33-executor-remediation-v6
repo=/mnt/d/Projects/OakGPT
output=$repo/runs/phase33/executor-marker-fix-v1/ros-qa
mkdir "$output"
source "$prefix/setup.bash"
export ROS_DOMAIN_ID=85 ROS_LOCALHOST_ONLY=1
cd "$repo"
colcon --log-base "$output/colcon-log" test --merge-install --base-paths "${prefix}-source/robotics/ros2_ws/src" --packages-select oak_mission oak_nav_trace --build-base "${prefix}-build" --install-base "$prefix" --test-result-base "$output/ros-results" > "$output/ros-test.log" 2>&1
colcon --log-base "$output/result-log" test-result --test-result-base "$output/ros-results" --verbose > "$output/ros-summary.log" 2>&1
ctest --test-dir "${prefix}-expiry" --output-on-failure -V > "$output/installed-expiry.log" 2>&1
python3 "$repo/runs/phase33/executor-marker-fix-v1/verify-installed.py" > "$output/runtime-identity.json"
printf '{"passed":true,"cpp_receipt":"../native-qa","note":"C++ release/ASan/UBSan passed before corrected Jazzy import; this fresh install reruns ROS and installed plugin tests"}\n' > "$output/COMPLETE.json"
